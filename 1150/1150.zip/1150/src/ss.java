
public class ss {
   public Double sqroot(Double d){
       System.out.println(Math.sqrt(d));
       return Math.sqrt(d);
   }

    public int calculatesum(int x ,int y){
       System.out.println(x+y);
return x+y;

    }
}
